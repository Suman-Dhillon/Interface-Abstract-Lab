﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceAbstractLabPart2
{
    internal class Dog : IAnimal
    {
        public Dog(string name, string colour, int height, int age) : base(name, colour, height, age) { }
    }
}
