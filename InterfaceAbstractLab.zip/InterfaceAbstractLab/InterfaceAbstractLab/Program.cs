﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceAbstractLab
{
    internal class Program
    {
        //Author: Sumandeep Kaur
        //Date: February 20, 2023
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Dog's name: ");
            string dogName = Console.ReadLine();

            Console.WriteLine("Enter Dog's colour: ");
            string dogColour = Console.ReadLine();

            Console.WriteLine("Enter Dog's age: ");
            string dogAge = Console.ReadLine();
            int dogAgeInt = int.Parse(dogAge);

            Dog dog1 = new Dog (dogName, dogColour, dogAgeInt);

            string dogInfo = dog1.ToString();
            Console.WriteLine(dogInfo);

            dog1.Eat();

            //Cat's Code
            
            Console.WriteLine("\n\nEnter Cat's name: ");
            string catName = Console.ReadLine();

            Console.WriteLine("Enter Cat's colour: ");
            string catColour = Console.ReadLine();

            Console.WriteLine("Enter Cat's age: ");
            string catAge = Console.ReadLine();
            int catAgeInt = int.Parse(catAge);

            Cat cat1 = new Cat(catName, catColour, catAgeInt);

            string catInfo = cat1.ToString();
            Console.WriteLine(catInfo);

            cat1.Eat();
        }
    }
}
