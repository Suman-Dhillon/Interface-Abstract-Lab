﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceAbstractLab
{
    internal class Cat : Animal
    {
        public Cat(string name, string colour, int age) : base(name, colour, age) { }

        public override void Eat()
        {
            Console.WriteLine("Cats eat mice");
        }
        public override string ToString()
        {
            return "Cat's name is " + Name + "\nCat's colour is " + Color + "\nCat's age is " + Age;
        }
    }
}
