﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceAbstractLab
{
    internal class Dog : Animal
    {
        public Dog(string name, string colour, int age) : base(name, colour, age) { }

        public override void Eat()
        {
            Console.WriteLine("Dogs eat meat");
        }

        public override string ToString()
        {
            return "Dog's name is " + Name + "\nDog's colour is " + Color + "\nDog's age is " + Age;
        }
    }
}
